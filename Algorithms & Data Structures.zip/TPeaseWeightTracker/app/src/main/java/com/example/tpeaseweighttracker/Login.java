package com.example.tpeaseweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Login extends AppCompatActivity {
    private EditText mUser;
    private EditText mPassword;
    private Button loginButton;
    private AppDatabase database;


    KeyGenerator keyGenerator;
    SecretKey secretKey;
    // ENCRYPTION SOURCE: https://www.amarinfotech.com/how-to-do-aes-256-encryption-decryption-in-android.html
    public SecretKey initializeEncryption() {
        try {
            keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            secretKey = keyGenerator.generateKey();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        byte[] IV = new byte[16];
        SecureRandom random;
        random = new SecureRandom();
        return secretKey;
    }
    public static byte[] encrypt(byte[] plaintext, SecretKey key, byte[] IV) throws Exception {
        Cipher cipher = Cipher.getInstance("AES");
        SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
        byte[] cipherText = cipher.doFinal(plaintext);
        return cipherText;
    }
    public static String decrypt(byte[] cipherText, SecretKey key, byte[] IV) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            SecretKeySpec keySpec = new SecretKeySpec(key.getEncoded(), "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(IV);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            byte[] decryptedText = cipher.doFinal(cipherText);
            return new String(decryptedText);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mUser = findViewById(R.id.textUsername);
        mPassword = findViewById(R.id.textPassword);
        loginButton = findViewById(R.id.loginButton);
    }

    public boolean validateUser(String username, String password) {
        if (database.validateUser(username, password) != -1){
            return true;
        }
        else {
            User newUser = new User(username, password);
            boolean userAdd = database.addUser(newUser);
            if (userAdd) {
                Toast.makeText(getApplicationContext(), "User Was Not in System - Added", Toast.LENGTH_SHORT).show();
                return true;
            }
            else {
                Toast.makeText(getApplicationContext(), "User Was Not in System - Failed to Add", Toast.LENGTH_SHORT).show();
                return false;
            }
        }
    }
    public void signIn(View view) {
        //encryption start of password
        secretKey = initializeEncryption();
        String username = "";
        byte[] password;
        byte[] IV = new byte[16];
        SecureRandom random = new SecureRandom();
        random.nextBytes(IV);
        try {
            username = mUser.getText().toString();
            password = mPassword.getText().toString().getBytes();
            password = encrypt(password, secretKey, IV);
            String stringPassword = password.toString();
            if(validateUser(username, stringPassword)) {
                Intent intent = new Intent(this, MainActivity.class);
                startActivity(intent);
            }
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "An Error Occurred", Toast.LENGTH_SHORT).show();
        }
    }
}
