package com.example.tpeaseweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AddWeight extends AppCompatActivity {
    private EditText Date;
    private EditText Weight;
    private AppDatabase database;
    private Calendar myCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weightscreen);
        Date = findViewById(R.id.enterDate);
        Weight = findViewById(R.id.enterWeight);
        database = AppDatabase.getInstance(getApplicationContext());
    }
    public void addWeight(android.view.View view) {
        Toast.makeText(getApplicationContext(), Date.getText().toString() + Weight.getText().toString(), Toast.LENGTH_LONG).show();
        //String sDate = date.getDate() + "/" + (date.getMonth()+1) + "/" + (1900 + date.getYear());
        String sDate = Date.getText().toString();
        String sWeight = Weight.getText().toString();
        DailyWeight dailyWeight = new DailyWeight(sDate, sWeight);
        if (database.addDailyWeight(dailyWeight)) {
            Toast.makeText(getApplicationContext(), "Added Successfully!", Toast.LENGTH_LONG).show();
        }
        else { Toast.makeText(getApplicationContext(), "An Error Occurred", Toast.LENGTH_LONG).show(); }
    }
    // menu handling
    public void onClickHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onClickAddRecord(View view) {
        Intent intent = new Intent(this, AddWeight.class);
        startActivity(intent);
    }
}
