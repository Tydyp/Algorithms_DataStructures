package com.example.tpeaseweighttracker;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private AppDatabase database;
    private TextView CurrentTarget;
    private TextView CurrentWeight;
    private TargetWeight targetWeight;
    private DailyWeight dailyWeight;
    private String updateTarget;
    private String updateCurrent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        database = AppDatabase.getInstance(getApplicationContext());
    }
}

